# IE TRACK — Shared online website

This is a deploy-ready starter website for PUP BS Industrial Engineering students.
It includes:
- Secure email/password login and registration using Supabase Auth
- Shared activities visible to signed-in students
- Admin-only create/edit/delete controls for shared activities
- Private personal task lists for each student
- Supabase Row Level Security (RLS) policies to protect student data
- Maroon-and-gold responsive design for phones and computers

IMPORTANT: This folder is website code, not an already-published website. To share it with students, connect Supabase and deploy it to a hosting service. Do not publish it with placeholder configuration.

## Part 1 — Create the online database and authentication

1. Open https://supabase.com/ and sign up or log in.
2. Create a new project. Save the database password somewhere private.
3. Open the project's **SQL Editor**, create a new query, paste all of `supabase-setup.sql`, and run it.
4. Open **Project Settings → API** (or the project's API settings page).
5. Copy the **Project URL** and the **anon/public key**. The public/anon key is designed for use in the browser when Row Level Security is configured. NEVER use the `service_role` or secret key in website code.
6. In `index.html`, find:
   `const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";`
   `const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY_HERE";`
   Replace each placeholder with the correct Project URL and anon/public key.
7. In Supabase **Authentication → URL Configuration**, set the Site URL to your final deployed website URL after you deploy it. You may temporarily use the deployment URL while testing.
8. In Authentication settings, choose whether email confirmation is required. If enabled, students must confirm their email before logging in.

## Part 2 — Make your account the administrator

1. Register your own account through the website after connecting Supabase.
2. If email confirmation is enabled, confirm the email and log in once.
3. In Supabase, open **SQL Editor** and run the following query, replacing the email with your exact account email:

   update public.profiles
   set role = 'admin'
   where id = (select id from auth.users where email = 'you@example.com');

4. Log out of IE TRACK and log in again. You should now see the **Admin: manage activities** tab.
5. Do not run the admin query for students. All new accounts are students by default. Students cannot change their own role through the website.

## Part 3 — Publish it free on Vercel

Easy path (GitHub + Vercel):
1. Create an account at https://github.com/ if you don't have one.
2. Create a new repository, e.g. `ie-track`. Upload `index.html` and `supabase-setup.sql` (README is optional).
3. Open https://vercel.com/ and sign in with GitHub.
4. Choose **Add New → Project**, import the `ie-track` repository, then deploy. A plain HTML website needs no build command; Vercel should serve `index.html` from the project root.
5. Open the provided `*.vercel.app` URL. Test registration, email confirmation, login, personal tasks, and admin publishing.
6. In Supabase Authentication → URL Configuration, update **Site URL** to the exact Vercel URL. If the dashboard lists redirect URLs, add your Vercel URL as an allowed redirect URL.
7. Share the Vercel URL with students. They need an internet connection and their own accounts.

## How to use the site

- Admin: sign in, open **Admin: manage activities**, and choose **Publish activity**. Published activities appear in the shared activity board for all signed-in students.
- Student: sign in, view **Shared activities**, and use **My personal tasks** to add private tasks, mark them complete, edit, or delete them.
- Personal tasks are protected by RLS and only the signed-in owner can read/change them.
- Shared activities are readable by authenticated accounts; only the admin role can change them.

## Security and troubleshooting

- Never put a Supabase service-role/secret key in `index.html`, GitHub, or any browser-facing code.
- Keep the Supabase RLS policies enabled. Do not remove them.
- If the website shows “Setup required,” the two Supabase values in `index.html` have not been replaced correctly.
- If the admin tab is missing, make sure your account exists in `profiles`, the admin SQL used the correct email, then log out and back in.
- If account creation says to check email, open the confirmation message before logging in.
- If registration works but profile creation fails, check the SQL script ran successfully and the `on_auth_user_created` trigger exists.
- This project is a starter implementation. Before a large public launch, review Supabase usage limits, backups, and privacy obligations.
