-- IE TRACK Supabase setup
-- Run this entire script in Supabase > SQL Editor > New query.
-- Uses Supabase Auth and Row Level Security so students only access their own personal tasks.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.shared_activities (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 150),
  subject text not null default 'General',
  description text not null default '',
  deadline date,
  priority text not null default 'Normal' check (priority in ('Normal','High','Urgent')),
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.personal_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 150),
  subject text not null default 'Personal',
  description text not null default '',
  deadline date,
  priority text not null default 'Normal' check (priority in ('Normal','High','Urgent')),
  completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.shared_activities enable row level security;
alter table public.personal_tasks enable row level security;

-- Profile is created automatically when a new account signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name',''), 'student')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Helper checks the caller's role without recursive profile RLS.
create or replace function public.is_ie_track_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and p.role = 'admin'
  );
$$;
revoke all on function public.is_ie_track_admin() from public;
grant execute on function public.is_ie_track_admin() to authenticated;

-- Profiles: each user can read/update only their own profile.
create policy "Users read own profile" on public.profiles
for select to authenticated using (id = (select auth.uid()));
create policy "Users update own name" on public.profiles
for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));
-- Prevent users from changing their own role: column-level grants allow updating only full_name.
revoke update on public.profiles from authenticated;
grant update (full_name) on public.profiles to authenticated;
grant select on public.profiles to authenticated;

-- Shared activity board: signed-in users can read; admins alone can create/change/delete.
create policy "Signed-in users view shared activities" on public.shared_activities
for select to authenticated using (true);
create policy "Admins insert shared activities" on public.shared_activities
for insert to authenticated with check (public.is_ie_track_admin() and created_by = (select auth.uid()));
create policy "Admins update shared activities" on public.shared_activities
for update to authenticated using (public.is_ie_track_admin()) with check (public.is_ie_track_admin());
create policy "Admins delete shared activities" on public.shared_activities
for delete to authenticated using (public.is_ie_track_admin());

-- Personal tasks: owner-only read/create/update/delete.
create policy "Users view own tasks" on public.personal_tasks
for select to authenticated using (user_id = (select auth.uid()));
create policy "Users create own tasks" on public.personal_tasks
for insert to authenticated with check (user_id = (select auth.uid()));
create policy "Users update own tasks" on public.personal_tasks
for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "Users delete own tasks" on public.personal_tasks
for delete to authenticated using (user_id = (select auth.uid()));

grant select, insert, update, delete on public.shared_activities to authenticated;
grant select, insert, update, delete on public.personal_tasks to authenticated;

-- OPTIONAL: after you register your own account and confirm the email, run this
-- separately, replacing the email with YOUR exact account email.
-- Do not give admin role to ordinary students.
-- update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'you@example.com');
